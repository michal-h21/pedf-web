---
title: Děkanský den 8. 3. 2017
---

Ve středu 8. 3. 2017 bude celá Ústřední knihovna zavřena – děkanský den.
Výpůjčky, které měly být v tento den vráceny, jsou prodlouženy do 13. 3. 2017.

