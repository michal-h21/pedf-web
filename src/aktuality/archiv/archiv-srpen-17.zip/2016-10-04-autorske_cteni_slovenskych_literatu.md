---
title: Autorské čtení slovenských literátů
---

Ústřední knihovna PedF UK ve spolupráci s Obcí spisovatelů ČR a katedrou české
literatury PedF UK srdečně zve studenty, zaměstnance a další zájemce na
**autorské čtení slovenských literátů a jejich hostů s besedou a hudebním
doprovodem**. Pozvání přijali: *Zuzana Kuglerová, Miroslav Bielik, Ondrej Kalamár*
a *Ján Tazberík*. Hudební doprovod: *Marie Dunovská*. Akce se uskuteční
ve středu **5. října 2016 od 17 hodin** ve studovně Ústřední knihovny PedF UK,
Magdalény Rettigové 4, Praha 1.
