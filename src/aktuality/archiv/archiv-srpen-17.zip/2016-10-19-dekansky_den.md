---
title: Děkanský den
---
Celá Ústřední knihovna je 27. 10. 2016 zavřena – děkanský den. Výpůjčky, které
měly být v tento den vráceny, jsou prodlouženy do 1. 11. 2016.

