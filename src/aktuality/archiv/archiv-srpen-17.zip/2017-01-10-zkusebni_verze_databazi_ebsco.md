---
title: Zkušební verze databází EBSCO
---

Do konce března 2017 jsou zpřístupněny zkušební verze **databází EBSCO** zaměřené
na **hudbu**, **humanitní vědy** a **akademická periodika**. Jejich seznam naleznete na
[Portálu elektronických
zdrojů](http://pez.cuni.cz/prehled/freetrials.php?lang=cs), vyhledávat v nich
můžete i v [EDS](http://ukaz.cuni.cz).
