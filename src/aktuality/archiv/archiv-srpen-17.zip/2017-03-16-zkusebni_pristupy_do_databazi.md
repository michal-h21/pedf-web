---
title: Zkušební přístupy do databází
---

Do 30. 4. máte možnost zkušebního přístupu do databáze  *ProQuest Dissertations
& Theses Global*. Obsahuje více než 2 miliony disertačních a diplomových prací
z předních světových univerzit. Více informací naleznete v
[letáku](/img/1598-aip-pqdt-letak.pdf).

Do 15. 5. máte k dispozici zkušební přístup ke všem časopisům a knižním sériím
vydavatelství Emerald. Více informací naleznete na [Portálu elektronických
zdrojů](http://pez.cuni.cz/prehled/zdroj.php?lang=cs&id=743&freetrials=1).

