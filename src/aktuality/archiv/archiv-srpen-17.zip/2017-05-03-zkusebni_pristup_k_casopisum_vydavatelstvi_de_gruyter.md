---
title: Zkušební přístup k časopisům vydavatelství De Gruyter
---

Až do 30. 6. je možný zkušební přístup k časopisům vydavatelství [De
Gruyter](http://pez.cuni.cz/prehled/zdroj.php?lang=cs&id=704&freetrials=1))

