---
title: Přednáška o díle R. M. Rilka
---


Ústřední knihovna PedF UK srdečně zve na přednášku doc. PhDr. Viery Glosíkové,
CSc. "Dílo R. M. Rilka v českém a evropském kontextu", která se uskuteční 15.
prosince 2016 od 18:00 ve studovně knihovny, v přízemí Magdalény Rettigové 4.
