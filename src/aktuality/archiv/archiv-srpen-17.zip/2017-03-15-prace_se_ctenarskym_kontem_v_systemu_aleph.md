---
title: Práce se čtenářským kontem v systému ALEPH
---

Víte, jak si zarezervovat knihu? Jak si online prodloužit výpůjčky? Vše o práci
se čtenářským kontem v systému ALEPH se dovíte v prezentaci, kterou pro zájemce
z řad studentů i zaměstnanců připravila Ústřední knihovna PedF. Zveme Vás do
studovny v přízemí Magdalény Rettigové 4 dne 3. dubna 2017 ve 14 hodin.

