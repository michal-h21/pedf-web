---
title: Nové knihy v dubnu
---

Na stránce [nové knihy](/nove_knihy/index.html) si můžete prohlédnout seznam knih a kvalifikačních prací,
které byly zařazeny do fondu knihovny v průběhu dubna.

