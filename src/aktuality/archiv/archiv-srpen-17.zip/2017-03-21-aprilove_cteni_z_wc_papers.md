---
title: „Aprílové čtení z WC Papers“ aneb „ Literární poklesky chemiků a chemické poklesky literátů“
---

Ústřední knihovna PedF UK a Univerzita třetího věku srdečně zvou na seznámení s
literárními poklesky chemiků a chemickými poklesky literátů, které se uskuteční
12. dubna 2017 od 14 hodin v učebně R 231.

