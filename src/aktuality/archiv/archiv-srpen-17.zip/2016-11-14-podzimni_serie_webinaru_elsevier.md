---
title: Podzimní série webinářů Elsevier
---

Společnost Elsevier připravila několik webinářů pro uživatele jejích produktů.
Vše bude probíhat v českém jazyce a účastníci budou moci přímo pokládat otázky
školiteli.

- Pondělí 21. 11. 2016, 13–14 h: ScienceDirect - novinky a vylepšení (Barbora Ševčíková). [Registrace](https://attendee.gotowebinar.com/register/8523582741859187713)
- Čtvrtek 8. 12. 2016, 10–11 h: Scopus (Dr. Jiří Jirát). [Registrace](https://attendee.gotowebinar.com/register/4628319808770657796)

