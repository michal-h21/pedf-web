---
title: Autorská poetika a interkulturní aspekty recepce díla Michaela Endeho
---

Ústřední knihovna PedF UK zve všechny zájemce na přednášku PhDr. Tamary
Bučkové, Ph.D. o díle německého spisovatele fantasy a literatury pro děti,
Michaela Endeho. Přednáška se uskuteční ve čtvrtek 2. března 2017 od 17:30
hodin ve studovně ÚK v přízemí budovy fakulty Magdalény Rettigové 4, Praha 1.

