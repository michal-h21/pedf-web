---
title: Vyhledávání v informačních zdrojích pomocí discovery služby UKAŽ
---
Ústřední knihovna PedF UK zve studenty a zaměstnance na seznámení s
celouniverzitní vyhledávací službou „Ukaž“, která umožňuje studentům a
zaměstnancům Univerzity Karlovy prohledávat z jednoho místa dostupné
elektronické zdroje a tištěné dokumenty umístěné v knihovnách UK. Prezentace
proběhne v pondělí 6. března od 14 hodin ve studovně ÚK v budově fakulty
Magdalény Rettigové 4.

