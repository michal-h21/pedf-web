---
title: Dvorky v knihovně
---

Knihovna se se připojuje ke studentské akci DVORKY 2016. Program a více informací naleznete v [letáku](img/dvorky2016.pdf).
