---
title: Informativní setkání katederních správců OBD
---

Ústřední knihovna PedF UK zve na informativní setkání katederních správců OBD,
které proběhne 6. února 2017 od 14 hodin ve Studovně ÚK v budově fakulty
Magdalény Rettigové 4. Vítáni jsou i další zájemci o problematiku sběru dat o
publikační činnosti z PedF UK.
