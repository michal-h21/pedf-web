---
title: Noc literatury
---

Ve středu 10. května proběhne akce [Noc
literatury](http://www.nocliteratury.cz/cs/2017/).  Ta přibližuje veřejnosti
netradičním způsobem současnou evropskou literaturu prostřednictvím série
veřejných čtení. Záměrem akce je netradičním způsobem přiblížit veřejnosti
současnou evropskou literaturu prostřednictvím série veřejných čtení v
atraktivních, či běžně nepřístupných místech. Výběr ze současné evropské
literární scény poodhalí kouzlo velkých i malých literatur v přednesu hereckých
osobností, které vám představí ukázky z nových překladů děl evropských autorů.
Akci organizují Česká centra ve spolupráci s pražským sdružením evropských
kulturních institutů sítě EUNIC (European Union National Institutes for
Culture) a kulturními odděleními zahraničních velvyslanectví.  Odehrává se
nejen v Praze, ale také na pobočkách Českých center v zahraničí a ve spolupráci
se Svazem knihovníků a informačních pracovníků také v dalších městech České
republiky.

