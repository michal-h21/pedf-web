---
title: Výstavka publikací
---

V rámci oslav 70. výročí založení fakulty knihovna uspořádala výstavu publikací
o fakultě a jejích pracovnících. Můžete si ji prohlédnout ve studovně do 23. listopadu.
Snímky výstavy si najdete ve [fotogalerii](foto_pedf_knihy_16.html).
