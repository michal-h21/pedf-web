---
title: Webináře WOS
---

Ústřední knihovna PedF nabízí možnost sledovat ve studovně webináře pro začínající uživatele produktů společnosti Claritative Analytics:

- *10. 4. 2017*, 10:00 - 11:30

  **Web of Science Core Collection** – mezinárodní citační databáze vědeckých článků, konferenčních příspěvků a vědeckých monografií se záznamy od roku 1900 do současnosti.

- *11. 4. 2017*, 10:00 - 11:30

  **Journal Citations Reports** – analytický nástroj pro hodnocení časopisů.
