---
title: Seminář věnovaný otevřenému přístupu v akademickém publikování
---
Program:

- Tereza Simandlová: Co je a není otevřený časopis - kvalitativní standardy dle DOAJ
- České časopisy v DOAJ - příklady dobré praxe

Seminář se uskuteční 18. října 2016 od 15:00 do 17:00 hodin ve Velké zasedací místnosti, Karolinum, Ovocný trh 5/560, Praha 1.
